'use strict'
const aws = require('aws-sdk'); 
const express = require('express');
const router = require('express').Router();
const mongoose = require('mongoose');
// MODELS 
const userSchema = require('./models/usersSchema');
// const DB_HOST = process.env.DB_HOST;
const DB_HOST = 'mongodb+srv://ph03nix:qbZS0YnYJEacAMbk@cluster0-srdla.mongodb.net/users?retryWrites=true&w=majority';

//Set up default mongoose connection
// var mongoDB = 'mongodb://localhost:27017/users';//base de datos local
var mongoDB = 'mongodb+srv://ph03nix:qbZS0YnYJEacAMbk@cluster0-srdla.mongodb.net/users?retryWrites=true&w=majority';//conexion remota
mongoose.connect(mongoDB, {useNewUrlParser: true}, console.log('success connection'));
mongoose.Promise = global.Promise;// Get Mongoose to use the global promise library
var db = mongoose.connection;//Get the default connection
db.on('error', console.error.bind(console, 'MongoDB connection error:'));//Bind connection to error event (to get notification of connection errors)


