# trivia-t-Skill
Example Skill Alexa
